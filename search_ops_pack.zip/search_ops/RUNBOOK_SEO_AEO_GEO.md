# Search Operations Runbook
SEO, AEO, GEO Execution Guide
Version 1.0

## Operating Principle

Search work is controlled experimentation.

---

## Standard Flow

1. Intake
2. Property mapping
3. Baseline capture
4. Inspection
5. Signal mapping
6. Backlog creation
7. Sandbox execution
8. Validation
9. Reporting

---

## Failure Modes

- Skipping baseline
- Mixing environments
- Claiming causation
- Ignoring evidence gaps

---

## Escalation Rules

Escalate when:
- Evidence conflicts
- Validation fails
- Risk increases

---

End of RUNBOOK_SEO_AEO_GEO.md
