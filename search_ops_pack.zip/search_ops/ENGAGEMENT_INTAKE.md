# Engagement Intake
SEO, AEO, GEO Client Onboarding Intake
Version 1.0

## 1. Client and Site Identification

- client_name:
- client_slug:
- primary_contact:
- billing_contact:
- site_name:
- site_slug:
- primary_domain:
- secondary_domains:
- primary_market:
- target_countries:
- target_languages:

## 2. Business Goals and Constraints

### Goals (ranked)
1.
2.
3.

### Constraints
- Budget constraints:
- Timeline constraints:
- Legal or compliance constraints:
- Content approval constraints:
- Brand or tone constraints:

## 3. Technical Stack

- CMS or framework:
- Hosting provider:
- CDN:
- DNS provider:
- Analytics setup present:
- Tag manager present:
- Server access available:
- Repo access available:

## 4. Access Inventory (Read First)

- GSC access level:
- GA4 access level:
- GTM access level:
- GBP access level:
- CMS access level:
- Hosting access level:
- Repo access level:
- Sandbox availability:

## 5. Existing Clarities and Risks

- Known penalties:
- Known migrations:
- Known downtime events:
- Known tracking issues:
- Known duplicate domains:
- Known canonical conflicts:

## 6. Deliverable Expectations

- Reporting cadence:
- Primary KPI definition:
- Secondary KPI definition:
- Approval workflow:
- Stakeholder list:

## 7. Evidence and Claims Policy

All material claims will be:
- Classified
- Supported by admissible evidence or labeled
- Validated where feasible
- Cited in APA format when external authority is used

Client acknowledges that:
- search outcomes are probabilistic
- timelines are estimates
- causation will not be claimed without validation

End of ENGAGEMENT_INTAKE.md
