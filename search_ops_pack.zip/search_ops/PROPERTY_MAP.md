# Property Map
Google and Measurement Property Canonicalization
Version 1.0

## Site Identity

- client_slug:
- site_slug:
- canonical_domain:
- canonical_protocol:
- canonical_www_policy:

## Google Search Console

- property_type: (domain or URL prefix)
- property_identifier:
- verified_owners:
- delegated_access:
- sitemap_locations:

## Google Analytics 4

- property_name:
- property_id:
- data_streams:
- conversions_defined:
- filters_defined:
- retention_setting:

## Google Tag Manager

- container_name:
- container_id:
- environments:
- publish_rights:

## Google Business Profile (If Applicable)

- profile_name:
- profile_id:
- locations:
- ownership_status:

## Notes

- Any known mismatches or duplicates:
- Any prior properties still collecting data:

End of PROPERTY_MAP.md
