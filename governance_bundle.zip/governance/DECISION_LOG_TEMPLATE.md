# Decision Log Template
The Little Design Group Consulting Standards

## Decision ID
Unique identifier for this decision.

---

## Date
YYYY-MM-DD

---

## Decision Statement

Clearly state the decision.

---

## Context

Explain the situation that required a decision.

---

## Assumptions

List explicit assumptions.

---

## Alternatives Considered

Describe viable alternatives and why they were not selected.

---

## Tradeoffs

Describe tradeoffs introduced by this decision.

---

## Consequences

Describe downstream impacts and dependencies.

---

## Validation Plan

Define how this decision will be validated.

---

## Evidence and Citations

List supporting evidence with APA formatted citations where applicable.

---

## Instructor Notes (Required if decision is non obvious)

> **Instructor Note**
> Purpose:
> Explanation:
> Common pitfalls:
> Why this matters:
> How to validate:

---

End of DECISION_LOG_TEMPLATE.md
