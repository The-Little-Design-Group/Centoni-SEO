# Pull Request Template
The Little Design Group Consulting Standards

## Summary

Brief description of what this PR does.

---

## Related Tickets or Decisions

- Jira ticket:
- Decision log entry:

---

## Scope Confirmation

- [ ] Changes are within approved scope
- [ ] Out of scope items are explicitly excluded

---

## Governance Compliance Confirmation

- [ ] TLDG Consulting Standards reviewed
- [ ] PREFLIGHT_CHECKLIST.md completed
- [ ] No em dashes or emojis
- [ ] No anthropomorphic language
- [ ] Instructor Notes included where required
- [ ] Citations validated and admissible where applicable

---

## Validation Performed

Describe how changes were validated.

---

## Risks

Describe any known risks introduced by this change.

---

## Rollback Plan

Describe how to revert this change if necessary.

---

## Final Confirmation

I confirm this pull request complies with The Little Design Group Consulting Standards.

---

End of PULL_REQUEST_TEMPLATE.md
