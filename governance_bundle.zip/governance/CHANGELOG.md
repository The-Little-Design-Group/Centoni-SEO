# CHANGELOG.md
The Little Design Group Consulting Standards Governance Bundle

## v1.2
- Expanded consulting standards to include formal definitions, scope control, and deterministic documentation requirements.
- Added two audience plane model and formal Instructor Notes requirements, including validation guidance and junior enablement expectations.
- Added detailed research integrity section including source admissibility categories, vetting rubric, APA rules, and double verification standards.
- Expanded tool and MCP governance including client separation keys, read first defaults, and audit trail requirements.
- Expanded preflight checklist to include mechanism first validation, instructional markup checks, and citation vetting.
- Expanded violation protocol with fatal versus correctable classes and explicit remediation procedures.

## v1.1
- Added instructional pedagogy requirements.
- Added research integrity and citation governance.
- Added APA citation enforcement.

## v1.0
- Initial governance framework.
