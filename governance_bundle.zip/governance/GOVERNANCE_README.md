# Governance README
The Little Design Group Consulting Standards Integration Guide
Version 1.0

## Purpose

This document defines how The Little Design Group Consulting Standards are operationalized across repositories, tickets, pull requests, and agent workflows.

The goal is to ensure standards are enforced at the point of execution, not retroactively.

---

## Required Governance Files

Every repository operating under The Little Design Group name must include the following directory:

```
/governance/
  TLDG_CONSULTING_STANDARDS.md
  SYSTEM_PROMPT.md
  PREFLIGHT_CHECKLIST.md
  VIOLATION_PROTOCOL.md
  CHANGELOG.md
```

No repository is considered compliant without these files present.

---

## Required Repository References

### README.md

Every repository README.md must include the following statement:

```
This repository operates under
The Little Design Group Consulting Standards (TLDG-CS).

All artifacts, decisions, and implementations must comply with those standards.
```

---

## Jira Integration Requirements

### Epic Level
Each Jira epic must include:
- A reference to TLDG-CS
- A statement that acceptance criteria must meet governance standards
- A link to the relevant repository

### Ticket Level
Each ticket must:
- State scope and constraints
- Define validation criteria
- Reference governing standards explicitly

Tickets that do not meet these requirements are considered incomplete.

---

## Pull Request Enforcement

Every pull request must:
- Reference a Jira ticket or decision log
- Confirm PREFLIGHT_CHECKLIST.md compliance
- State whether Instructor Notes were required and included
- Confirm citation validation when claims are present

Pull requests lacking this confirmation must not be merged.

---

## Junior and Agent Usage

Juniors and agents must:
- Read TLDG_CONSULTING_STANDARDS.md before contributing
- Use provided templates without modification
- Include Instructor Notes where required
- Escalate evidence uncertainty rather than guessing

Failure to comply is treated as a process violation, not an individual failure.

---

## Governance Escalation

If a conflict arises between:
- Speed and standards
- Tool output and evidence requirements
- Convenience and correctness

Standards prevail.

---

End of GOVERNANCE_README.md
