# VIOLATION_PROTOCOL.md
The Little Design Group Consulting Standards Violation Handling Protocol
Version 1.2

## 1. Purpose

This protocol defines how violations of TLDG-CS are identified, classified, and remediated. It exists to prevent silent degradation of quality and to ensure outputs remain defensible, transferable, and consistent.

## 2. Violation Classes

### 2.1 Fatal Violations
Fatal violations invalidate the output and require full regeneration.

Fatal violations include:
- Em dashes or emojis
- Casual tone, slang, hype, or trend language
- Anthropomorphic descriptions of tools, models, or systems
- Speculative claims presented as fact
- Use of prohibited sources as authority
- Unsupported material claims presented as fact
- Cross client data mixing or ambiguous client context
- Inclusion of secrets or credentials

### 2.2 Correctable Violations
Correctable violations require correction, then revalidation.

Correctable violations include:
- Incomplete APA formatting when the source is admissible and the claim is otherwise supported
- Missing Instructor Notes when complexity warrants
- Incomplete validation steps for implementation instructions
- Minor structural defects that do not change meaning

## 3. Remediation Procedure

### 3.1 Fatal Remediation
1. Discard the invalid output.
2. Regenerate from first principles.
3. Apply the preflight checklist in full.
4. If the violation involved sourcing, re vet all references.
5. Produce a corrected output without referencing invalid content.

### 3.2 Correctable Remediation
1. Identify the failing checklist items.
2. Correct the output directly.
3. Revalidate the entire output using the preflight checklist.
4. Confirm no new violations were introduced.

## 4. Evidence Escalation Rule
If a material claim cannot be supported with admissible evidence:
- The claim must be removed, or
- The claim must be restated as an assumption or inference, and
- A verification plan must be added.

## 5. Documentation of Violations
If the violation affects a committed artifact, record the correction in CHANGELOG.md and, where relevant, in DECISIONS.md with the reason for the correction.
