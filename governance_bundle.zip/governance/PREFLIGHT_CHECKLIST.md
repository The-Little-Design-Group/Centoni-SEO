# PREFLIGHT_CHECKLIST.md
The Little Design Group Consulting Standards Validation Checklist
Version 1.2

## A. Language Compliance
- [ ] American professional English is used throughout.
- [ ] No em dashes are present.
- [ ] No emojis are present.
- [ ] No casual tone, slang, hype, or trend language appears.
- [ ] No anthropomorphic descriptions of tools, models, or systems are present.
- [ ] Speculative statements are labeled as assumptions or inferences.

## B. Mechanism First Clarity
- [ ] System behavior is described using inputs, rules, constraints, outputs.
- [ ] Verification methods are stated for key behaviors.
- [ ] Instructions are testable and not ambiguous.

## C. Analytical Rigor
- [ ] Assumptions are explicit and labeled.
- [ ] Decisions are explicit and include rationale.
- [ ] Alternatives considered are stated when decisions are material.
- [ ] Tradeoffs are acknowledged.
- [ ] Scope boundaries are defined (in scope, out of scope).
- [ ] Risks and mitigations are stated when relevant.

## D. Authorial Voice and Cadence
- [ ] Executive developer and systems architect posture is maintained.
- [ ] Calm authority is present, with no persuasive framing.
- [ ] Sentences are focused on one primary idea.
- [ ] Lists provide hierarchy and accountability.

## E. Pedagogical Structure
- [ ] Purpose appears before implementation detail.
- [ ] Context and constraints are defined.
- [ ] The reason for the system or decision is explained.
- [ ] Decisions and tradeoffs are documented.
- [ ] Next steps and consequences are stated.

## F. Instructional Markup for Juniors and Agents
- [ ] Instructor Notes are included where complexity warrants.
- [ ] Instructor Notes use only the approved construct.
- [ ] File paths, modules, and validation steps are included for implementation items.
- [ ] Common pitfalls and rollback guidance are included when relevant.

## G. Research Integrity and Citations
- [ ] Material claims are identified.
- [ ] Material claims are supported by admissible evidence or labeled.
- [ ] Sources are vetted for authorship, provenance, methodology, relevance, independence, and date.
- [ ] Prohibited sources are not cited as authority.
- [ ] APA formatting is correct.
- [ ] Material claims are double verified when feasible.
- [ ] Single source claims are labeled and include a verification plan.

## H. Execution Integrity
- [ ] No secrets or credentials are included.
- [ ] No unauthorized production changes are implied.
- [ ] Read versus write intent is clear.
- [ ] Artifacts are traceable to repos or tickets.

All items must pass. If any item fails, the output is invalid and must be regenerated.
