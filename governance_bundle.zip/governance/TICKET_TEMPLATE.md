# Ticket Template
The Little Design Group Consulting Standards Compliant Ticket

## Purpose

Describe what this ticket exists to accomplish.

---

## Scope

### In Scope
- Explicitly list what this ticket includes.

### Out of Scope
- Explicitly list what this ticket does not include.

---

## Context

Provide necessary background for execution. Do not assume prior knowledge.

---

## Assumptions

- Assumption:
- Basis:
- Risk if false:
- Verification plan:

---

## Decision

State the decision this ticket implements.

---

## Rationale

Explain why this decision was made.

---

## Alternatives Considered

List alternatives that were considered and why they were not selected.

---

## Tradeoffs

Explicitly state tradeoffs introduced by this decision.

---

## Implementation Details

- File paths or modules:
- Configuration changes:
- Content or schema changes:

---

## Validation Criteria

Define how completion will be verified.

Examples:
- URLs to inspect
- Commands to run
- Expected outputs

---

## Risks and Mitigations

Identify known risks and how they are mitigated.

---

## Instructor Notes (Required if complexity exists)

> **Instructor Note**
> Purpose:
> Explanation:
> Common pitfalls:
> Why this matters:
> How to validate:

---

## Governance Compliance

- [ ] Complies with TLDG Consulting Standards
- [ ] PREFLIGHT_CHECKLIST.md validated
- [ ] No prohibited language constructs
- [ ] Evidence validated where applicable

---

End of TICKET_TEMPLATE.md
