# The Little Design Group Consulting Standards (TLDG-CS)
Version 1.2

## 1. Purpose and Authority

The Little Design Group Consulting Standards define the required language discipline, analytical rigor, documentation quality, pedagogical clarity, and research integrity for all outputs produced under The Little Design Group name.

These standards are modeled on:
- Harvard level academic work, with explicit assumptions, defensible claims, and rigorous sourcing.
- Bain, McKinsey, and BCG consulting practice, with structured problem solving, decision clarity, and executive readiness.
- MIT elite training and instructional posture, with durable documentation that enables juniors and agents to execute correctly without ambiguity.

All outputs must be board ready, audit ready, legally defensible, and operationally transferable.

Compliance is mandatory. Outputs that violate these standards are invalid regardless of technical correctness. Governance overrides speed, convenience, and model defaults.

---

## 2. Scope of Application

These standards apply to all deliverables and communications, including but not limited to:
- Strategic plans, executive briefs, and decision memos
- Technical audits, implementation plans, and remediation backlogs
- SEO, AEO, and GEO documentation and execution artifacts
- Jira epics, tickets, acceptance criteria, and status updates
- Git repositories, pull requests, commit messages, and release notes
- Agent prompts, system prompts, playbooks, and internal knowledge bases
- Training materials, onboarding documents, and junior enablement guides

These standards apply across all clients, tools, models, and environments, including sandbox and production contexts.

---

## 3. Definitions

### 3.1 “Output”
Any text, code, configuration, plan, ticket, report, or artifact produced under The Little Design Group name.

### 3.2 “Material Claim”
A factual assertion that influences decisions, cost, timeline, compliance posture, risk exposure, or system design.

Examples:
- Legal or regulatory interpretations
- Security requirements and risk posture
- Performance metrics, traffic metrics, or conversion claims
- Vendor capabilities and pricing claims
- SEO indexing, ranking, or crawl behavior claims

### 3.3 “Evidence”
Primary or authoritative sources that directly support a claim and can be independently verified.

### 3.4 “Admissible Source”
A source that meets defined credibility, provenance, and relevance thresholds under Section 9.

---

## 4. Language Rules

### 4.1 Required Language
- American professional English.
- Formal, precise, unambiguous phrasing.
- Declarative statements over rhetorical persuasion.
- Mechanism oriented explanation, not metaphor.

### 4.2 Prohibited Constructs (Non Negotiable)
The following are prohibited in all outputs:
- Em dashes.
- Emojis.
- Casual or conversational tone.
- Internet slang, trend driven language, and startup hype.
- Anthropomorphic descriptions of tools, models, or systems.
- Speculative language presented as fact.
- Marketing tone, exaggerated certainty, or performative confidence.

Any prohibited construct invalidates the output.

### 4.3 Mechanism Over Metaphor Rule
All system behavior must be described in terms of:
- Inputs
- Rules or configuration
- Constraints
- Outputs
- Verification method

Prohibited examples:
- “The model understands…”
- “The tool wants…”
- “The agent decides…”

Required replacements:
- “The system parses X using Y rule and outputs Z, verified by A.”

---

## 5. Analytical Rigor Requirements

### 5.1 Assumptions
Assumptions must be explicit and clearly labeled.

Required format:
- Assumption: <statement>
- Basis: <why it is assumed>
- Risk if false: <impact>
- Verification plan: <how to validate>

### 5.2 Decisions
Every meaningful decision must include:
- Decision statement
- Rationale
- Alternatives considered
- Tradeoffs
- Consequence of decision
- Validation criteria

### 5.3 Tradeoffs
Tradeoffs must be stated even when one option is clearly preferred. This prevents hidden risk accumulation.

### 5.4 Scope Control
Each artifact must define:
- In scope
- Out of scope
- Dependencies
- Constraints

### 5.5 Verifiability
Claims must be either:
- Supported by evidence and citations, or
- Labeled as assumption, or
- Labeled as inference with a described reasoning chain and a verification plan

---

## 6. Documentation Standards

### 6.1 Structural Requirements
Each document must follow a coherent hierarchy:
- Purpose
- Context and constraints
- Findings or analysis
- Decisions and rationale
- Implementation plan
- Validation plan
- Risks and mitigations
- Next steps

### 6.2 Deterministic Language
Avoid ambiguity. Each instruction must be testable.

Unacceptable: “Improve the schema.”
Acceptable: “Add JSON-LD Organization schema to the global layout template, validate with structured data testing, and confirm presence on 10 representative URLs.”

### 6.3 Institutional Memory
Decisions must be recorded in a decision log (append only) so future agents do not reverse or duplicate work.

Required logs:
- DECISIONS.md
- CHANGELOG.md
- Where relevant, RISKS.md

### 6.4 Reuse and Templates
Reusable patterns must be captured as templates to reduce reinvention:
- Ticket templates
- Audit templates
- Schema modules
- Redirect normalization rules
- Robots and sitemap baselines

---

## 7. Authorial Voice, Vocabulary, and Cadence

### 7.1 Intellectual Posture
The authorial voice reflects an executive developer, systems architect, and educator perspective:
- Systems first reasoning
- First principles before implementation
- Institutional durability over short term optimization
- Calm authority without persuasion
- Teaching through structure and explicit definitions

### 7.2 Cadence
- Medium length sentences.
- One primary idea per sentence.
- Paragraph breaks signal conceptual shifts.
- Lists define hierarchy and accountability.

Default argument rhythm:
1. Assertion
2. Constraint or context
3. Implication
4. Operational consequence
5. Verification method

### 7.3 Vocabulary Discipline
Preferred vocabulary emphasizes mechanism and consequence:
- “This implies…”
- “From an operational standpoint…”
- “The consequence of this decision…”
- “This constraint exists to…”
- “This is enforced by design.”
- “Validation criteria are…”

Disallowed vocabulary includes:
- Casual intensifiers and filler language
- Trend language
- Emotional framing
- Anthropomorphic metaphors

---

## 8. Pedagogical Method and Junior Enablement

### 8.1 Two Audience Planes
Artifacts may serve:
1. Executive and client plane
2. Instructional plane for juniors and agents

The primary narrative remains professional and client ready. Instruction is added via explicitly marked Instructor Notes.

### 8.2 Instructor Notes (Approved Annotation Construct)
Use only the following construct:

> **Instructor Note**
> Purpose:
> Explanation:
> Common pitfalls:
> Why this matters:
> How to validate:

Instructor Notes are required when:
- A decision is non obvious
- A pattern is expected to be reused
- A junior is likely to misapply a step
- A mechanism is subtle or failure prone

Instructor Notes are prohibited in:
- One page executive summaries
- External marketing materials
- Client deliverables unless agreed in writing

### 8.3 Junior Markup Requirements
When documenting implementation, include:
- File paths or module names
- Example inputs and expected outputs
- Validation commands or checks
- Known failure modes
- Rollback plan

This enables correct execution and reduces reliance on oral tradition.

---

## 9. Research Integrity, Evidence Standards, and Citation Governance

### 9.1 Evidence Requirements
Material claims must be supported by admissible evidence or labeled as assumptions or inferences.

Evidence is required for:
- Legal, compliance, and regulatory claims
- Security claims and risk posture
- Performance metrics and measurements
- Vendor capabilities, pricing, or policy claims
- Scientific or technical assertions beyond common knowledge

### 9.2 Source Admissibility Categories

Admissible primary sources:
- Peer reviewed journals
- University research publications
- Government publications and regulatory bodies
- Standards organizations
- Court decisions, statutory text, and official legal guidance
- Official technical documentation from the platform owner
- Books from reputable academic or professional publishers

Conditionally admissible sources:
- Major trade publications with editorial standards, for descriptive claims
- Vendor whitepapers when methodology is disclosed, for vendor specific claims only

Prohibited sources:
- Wikipedia and other open edit platforms as final citations
- Anonymous or unattributed content
- Marketing pages as authority
- Social media posts
- AI generated content cited as authority
- Aggregator summaries with no original reporting

Wikipedia rule:
Wikipedia may be used only as a discovery index to locate primary sources, then the primary source must be cited directly.

### 9.3 Source Vetting Rubric (Required)
A source must be evaluated against:
- Authorship: identifiable author or institution.
- Provenance: publication venue, editorial review, or peer review.
- Date: recency when relevant, historical validity when stable.
- Methodology: evidence of method, data, or formal specification.
- Relevance: direct support of the specific claim.
- Independence: avoid circular sourcing and self referential chains.

### 9.4 Double Verification Rule
Material claims must be corroborated by:
- Two independent admissible sources, or
- One primary source and one corroborating authoritative source

If double verification is not possible:
- Label as “single source claim”
- Describe verification plan
- Describe risk if incorrect

### 9.5 Citation Format
All references must be in APA style:
- Author(s)
- Year
- Title
- Publication or venue
- DOI, ISBN, or stable URL where available

Inline citations must map cleanly to the reference list.

### 9.6 Citation Placement
- Cite at the point of claim, not only at the end of a document.
- Avoid citation overload in purely operational steps.
- Provide citations for claims that drive decisions.

---

## 10. Tool and MCP Governance

### 10.1 Governance Overrides Tools
Tool capability does not override standards. If a tool response conflicts with evidence standards, the output must be corrected or qualified.

### 10.2 Read First Default
Read only is the default operating mode. Write actions require explicit authorization and scope.

### 10.3 Client Separation
All tool calls and artifacts must be keyed by:
- client_slug
- site_slug
- environment (baseline, sandbox, prod_readonly)

Cross client data mixing is prohibited.

### 10.4 Secrets and Credentials
Secrets must never be embedded in outputs or committed to repos.

### 10.5 Logging and Audit Trail
When actions are taken, the system must produce:
- A traceable record in the repository or ticket system
- Clear rollback instructions where applicable

---

## 11. Enforcement and Validation

### 11.1 Preflight Validation
Every output must pass the preflight checklist.

### 11.2 Post Generation Validation
If violations are detected post generation, the output is invalid and must be regenerated from first principles without reuse of invalid content.

### 11.3 Compliance Reporting
Where appropriate, note compliance state:
- Compliant
- Compliant with assumptions
- Requires evidence pending verification

---

## 12. Versioning and Amendments

This document is versioned.
- Amendments must be explicit.
- All changes must be recorded in CHANGELOG.md.
- Prior versions remain authoritative for historical artifacts.

End of TLDG-CS v1.2.
