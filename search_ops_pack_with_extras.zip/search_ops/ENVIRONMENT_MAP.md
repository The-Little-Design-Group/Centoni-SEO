# Environment Map
Website Access and Execution Environments
Version 1.0

## Environments

### baseline
Definition: snapshot of current production explanation and known constraints.
Access: read only.

- URL:
- access_method:
- parity_notes:

### sandbox
Definition: controlled environment for changes and validation.
Access: read and write.

- URL:
- access_method:
- parity_notes:

### production_readonly
Definition: production verification only.
Access: read only.

- URL:
- access_method:
- restrictions:

### production_write (Only if approved)
Definition: production change execution.
Access: write.

- URL:
- access_method:
- approval_reference:
- rollback_owner:

## Deployment Path

- Git based deploy:
- CI/CD present:
- Manual promotion steps:
- CMS staging workflow:
- Emergency rollback method:

End of ENVIRONMENT_MAP.md
