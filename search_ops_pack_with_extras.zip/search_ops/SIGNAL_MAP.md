# Signal Map
SEO, AEO, GEO Signal Targeting
Version 1.0

## Purpose

This document maps remediation efforts to explicit search signal categories.

No action is permitted without signal classification.

---

## SEO Signals

| Signal | Current State | Action Required | Validation Method |
|------|--------------|----------------|-------------------|
| Crawlability | | | |
| Indexation | | | |
| Internal Linking | | | |
| Page Relevance | | | |
| Performance | | | |

---

## AEO Signals

| Signal | Current State | Action Required | Validation Method |
|------|--------------|----------------|-------------------|
| Entity Clarity | | | |
| Question Coverage | | | |
| Schema Completeness | | | |
| Answer Extraction | | | |

---

## GEO Signals

| Signal | Current State | Action Required | Validation Method |
|------|--------------|----------------|-------------------|
| Location Entities | | | |
| Country Targeting | | | |
| Language Signals | | | |
| GBP Optimization | | | |

---

## Signal Prioritization

Ranked by:
- Impact
- Effort
- Risk

---

End of SIGNAL_MAP.md
