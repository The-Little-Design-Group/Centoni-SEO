# Additional MCP Categories
Search Operations Pack Extensions
Version 1.0

## Purpose

This document outlines optional but high impact Model Context Protocols (MCPs) that can extend and refine the delivery of SEO, AEO, and GEO engagements. These MCPs address quality assurance, infrastructure management, automation, and data stewardship. They are not mandatory for every engagement, but they offer clear value when the scope or complexity of the work warrants them.

## Monitoring and Quality Assurance MCPs

MCPs in this category provide automated testing and monitoring of websites. For example, a Playwright‑based MCP can run headless browser checks to confirm that canonical tags, structured data, and meta directives render correctly in multiple environments. A WebPageTest or Lighthouse MCP can produce lab performance reports that feed directly into your validation logs. These tools ensure that changes do not regress key signals and that page delivery meets expected baselines.

## Additional Google MCPs

Beyond Google Search Console and GA4, you may need to interact with Google Tag Manager, Merchant Center, Ads, or Business Profiles. MCPs for these services allow you to read configuration and performance data, manage inventory and feed health, or pull ad conversion metrics directly into your analysis. They should follow the same property and access mapping principles as the core Google MCP.

## CDN and Infrastructure MCPs

For clients using a CDN or edge services, a dedicated MCP is essential. A Cloudflare MCP, for instance, can manage DNS records, caching rules, redirect policies, and security configurations. By treating infrastructure as a governed resource, you ensure that DNS or cache changes are baselined, sandboxed, and reversible, with clear evidence of their impact on crawlability and performance.

## Performance Auditing MCPs

Performance MCPs integrate tools such as Lighthouse or WebPageTest into your workflow. They can be configured to run on sandbox or staging environments and to capture metrics such as First Contentful Paint, Total Blocking Time, and Largest Contentful Paint. Results are stored in the validation log and are used to confirm that remediation efforts do not negatively affect page load performance.

## Security and Compliance MCPs

Security and compliance MCPs connect to vulnerability scanning tools and policy checkers. They help detect issues such as exposed administrative endpoints, outdated software, missing TLS configurations, or non compliant cookie banners. By integrating these checks, you ensure that technical SEO improvements do not introduce new security or privacy risks.

## Content and Translation MCPs

If your clients operate in multiple languages or markets, content MCPs can support multilingual content generation and localization. These MCPs help standardize translation workflows, ensure that schema and structured data are localized correctly, and verify that on page content aligns with AEO requirements for different languages.

## Database and Storage MCPs

MCPs that interface with a database, such as Supabase, provide a central store for baselines, evidence logs, and runbook state. A Supabase MCP can write and read structured engagement data, enabling you to query historical baselines or quickly assemble evidence for reports. Access is governed and read versus write operations are explicitly separated.

## Workflow Automation MCPs

Automation MCPs integrate n8n or other workflow engines into your governance stack. They automate tasks such as cloning repositories with the standard structure, creating Jira tickets from backlog templates, running scheduled GSC/GA4 pulls, and alerting when tests fail. These workflows follow MCP #6 for agent behavior: they assist but do not decide or commit changes.

## Static Analysis and Code Quality MCPs

Where engagements involve significant code changes, a static analysis MCP can connect to linters and code quality tools appropriate for WordPress, Laravel, Yii, or Next.js. These MCPs detect duplicate meta tags, misconfigured headers, unescaped output, or other technical SEO faults before code reaches production. They also integrate with the commit and PR process defined in the Git MCP.

## Data Visualization MCPs

For executive communication, data visualization MCPs generate compliant charts and summaries using libraries such as Recharts. These MCPs take validated data and render dashboards or charts that follow your formatting and evidence standards. They do not infer new conclusions; they represent the vetted data visually for stakeholders.

## Selection Guidance

Selecting an MCP should follow the same principles you have applied to the core stack: does it produce trustworthy data, does it enforce a controlled change, or does it automate a repeatable task? MCPs that cannot be measured or that increase complexity without adding clear value should be avoided.

End of EXTRAS.md
