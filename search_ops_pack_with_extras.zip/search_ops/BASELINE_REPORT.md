# Baseline Report
Search Performance Baseline
Version 1.0

## Purpose

This document captures the factual baseline state of search performance prior to any intervention.

No optimization, claim, or recommendation is permitted without this baseline.

---

## Measurement Window

- Start date:
- End date:
- Rationale for window selection:

---

## Google Search Console Baseline

### Overall Performance

- Total clicks:
- Total impressions:
- Average CTR:
- Average position:

### Query Distribution

- Top branded queries:
- Top non branded queries:
- Question based queries:
- Long tail queries:

### Page Performance

- Top performing URLs:
- Low CTR high impression URLs:
- Indexed but low traffic URLs:

### Geographic Performance

- Primary countries:
- Secondary countries:
- Anomalies observed:

---

## Google Analytics Baseline

### Traffic Overview

- Organic sessions:
- Organic users:
- Engagement rate:
- Average engagement time:

### Conversions

- Defined conversions:
- Organic assisted conversions:
- Organic direct conversions:

---

## Indexation State

- Total indexed pages (GSC):
- Submitted pages:
- Excluded pages:
- Error pages:

---

## Observations (Facts Only)

List observed facts only. No interpretation.

---

## Known Data Limitations

- Tracking gaps:
- Sampling issues:
- Missing history:
- Configuration concerns:

---

## Baseline Integrity Statement

This baseline represents the best available factual state as of the measurement window above.

Any future claims must reference this baseline explicitly.

End of BASELINE_REPORT.md
