# Search Operations Pack
SEO, AEO, GEO Governance and Delivery System
Version 1.0

## Purpose

This folder contains the required artifacts for delivering SEO, AEO, and GEO engagements under The Little Design Group Consulting Standards.

This pack exists to:
- Standardize intake, measurement, and execution
- Prevent unverified claims and weak sourcing
- Enable consistent delivery across mixed CMS stacks
- Produce audit ready evidence and validation logs
- Support junior execution without unsafe autonomy

## Operating Principle

Search work is not a checklist. It is controlled, measured intervention.

All work must be:
- Scoped
- Measured
- Validated
- Reversible
- Traceable to evidence

## Required Inputs

Before starting execution, obtain:
- Google Search Console access
- Google Analytics access
- Tag Manager access (if in use)
- CMS or repository access (read first)
- Hosting access only if required
- A sandbox environment or equivalent staging path

## Required Outputs

Every engagement must produce:
- PROPERTY_MAP.md
- ENVIRONMENT_MAP.md
- BASELINE_REPORT.md
- INSPECTION_NOTES.md
- SIGNAL_MAP.md
- BACKLOG_TEMPLATE.md (as populated backlog)
- VALIDATION_LOG.md
- EVIDENCE_LOG.md
- REFERENCES.md
- REPORT_EXEC_SUMMARY.md

No engagement is considered complete without these artifacts.

## Enforcement

All outputs are governed by:
- /governance/TLDG_CONSULTING_STANDARDS.md
- MCP #3 (Google Search and Measurement)
- MCP #4 (Website Read and Write)
- MCP #5 (Evidence and Claim Validation)
- MCP #6 (Human and Agent Behavior)

End of search_ops/README.md
