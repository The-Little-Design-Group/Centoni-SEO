# Pull Request, Search Work

## Purpose
Describe the objective in one sentence.

## Scope
- Client:
- Site:
- Environment:
- Signal category: (SEO, AEO, GEO, performance, compliance)

## Changes Included
List the changes made. Be factual.

## Evidence and Claims
- Are there any claims in this PR? (yes or no)
- If yes, list each claim and its classification (observed fact, derived conclusion, inference, assumption).
- Link to supporting entries in search_ops/EVIDENCE_LOG.md and search_ops/REFERENCES.md as applicable.

## Validation Performed
- Sandbox validation completed: (yes or no)
- Playwright checks: (pass, not run, not applicable)
- Schema validation: (pass, not run, not applicable)
- Notes:

## Risks
- Risk level: (low, medium, high)
- Impact if wrong:
- Mitigation:

## Rollback Plan
Describe how to revert the change and how to verify rollback success.

## Governance Checklist
- No emojis used in any text or commit message
- No em dashes used in any text
- search_ops/VALIDATION_LOG.md updated if changes impact production behavior
- search_ops/CHANGELOG, or repo CHANGELOG updated where applicable

## Reviewer Notes
Anything a reviewer should pay attention to.
