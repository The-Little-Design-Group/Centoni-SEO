---
name: Search regression or bug
about: Report a regression affecting crawl, schema, analytics, or indexation
title: "bug, <client>, <site>, <short title>"
labels: ["bug", "search"]
assignees: []
---

## Summary
One sentence description of the issue.

## Impact
- What is affected:
- Severity: (low, medium, high)
- User impact:

## Observed Evidence
Provide links, screenshots, logs, or Playwright output references.

## Environment
- Baseline, sandbox, production_readonly, production_write:
- URL(s):

## Suspected Cause
If unknown, say unknown.

## Proposed Fix
If unknown, say unknown.

## Rollback
If production is impacted, state rollback steps or escalation requirement.
