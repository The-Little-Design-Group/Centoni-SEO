---
name: Search backlog item
about: Create a governed SEO, AEO, GEO backlog item
title: "search, <client>, <site>, <short title>"
labels: ["search"]
assignees: []
---

## Backlog Item
- ID:
- Client:
- Site:
- Signal category: (SEO, AEO, GEO, performance, compliance)
- Risk level: (low, medium, high)
- Dependencies:

## Description
Describe the remediation clearly and factually.

## Rationale
Explain why this action is required, reference baseline or inspection notes.

## Implementation Notes
- Files or URLs affected:
- CMS considerations:
- Environment:

## Validation Criteria
Define how success is verified.

## Rollback Plan
Define how this change is reversed.

## Evidence Reference
Link to relevant entries in search_ops/EVIDENCE_LOG.md.
