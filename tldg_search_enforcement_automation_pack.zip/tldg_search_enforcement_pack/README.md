# TLDG Search Enforcement and Automation Pack
Version 1.0

## Purpose

This pack turns the Search Operations Pack into an enforceable and repeatable delivery system for SEO, AEO, and GEO engagements.

It includes:
- GitHub Actions governance gates
- Search specific PR and issue templates
- Supabase schema, RLS policy guidance, and data dictionary
- n8n workflow governance, structure, and export placeholders
- Playwright test suite skeleton for SEO and schema regression checks
- Reusable schema snippets and content patterns

## How to Use

1. Copy this pack into the root of a client engagement repository.
2. Commit as the first operational commit after governance and search_ops are present.
3. Update Supabase connection settings, n8n credentials, and Playwright base URLs per client.
4. Enforce branch protections to require the governance workflow to pass before merge.

## Notes

This pack is governed by The Little Design Group Consulting Standards.
