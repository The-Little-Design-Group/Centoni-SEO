# MCP Selection Policy
Version 1.0

## Purpose

This policy governs how new MCPs are evaluated, adopted, and maintained for Search Ops.

## Admission Criteria

A candidate MCP must satisfy at least one:
- Produces trustworthy data used as observed facts
- Enforces a controlled change with rollback capability
- Automates a repeatable task that reduces error rates

## Rejection Criteria

Reject an MCP if:
- It increases complexity without measurable value
- It blurs read and write authority boundaries
- It cannot be audited or logged
- It requires sharing credentials in a non governed way

## Evaluation Steps

1. Define the use case and success metrics
2. Identify data sources and outputs
3. Validate access model and least privilege
4. Define rollback and failure handling
5. Run a pilot on a non critical site
6. Log results and decide with evidence

## Required Records

- search_ops/MCP_INVENTORY.md
- search_ops/MCP_RISK_REGISTER.md

End of MCP_SELECTION_POLICY.md
