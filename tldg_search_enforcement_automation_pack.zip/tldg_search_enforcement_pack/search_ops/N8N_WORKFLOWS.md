# n8n Workflows, Search Ops
Version 1.0

## Purpose

This document defines approved automation workflows for SEO, AEO, and GEO operations.

Automations assist discipline. They do not decide, merge, or override governance checks.

## Approved Workflows

1. Repository bootstrap
   - Creates repo structure, copies governance and search_ops templates, creates initial commit.

2. Access checklist reminders
   - Sends reminders until required accesses are confirmed and logged.

3. Scheduled data pulls
   - Weekly or monthly pulls from GSC and GA4, stores raw exports and updates baseline entries.

4. Validation orchestration
   - Triggers Playwright checks in sandbox, records results into validations table.

5. Ticket creation
   - Creates Jira epics and tickets from backlog items, links ticket keys back to backlog_items.

6. Failure notifications
   - Alerts Slack, SMS, or email when governance checks fail or validations fail.

## Prohibited Workflows

- Merging to main
- Modifying production systems directly
- Editing evidence logs without review
- Silently overriding failed checks

## Required Logging

Each workflow must log:
- Trigger source
- Inputs
- Outputs
- Errors and retries
- Downstream actions taken

Exports should live in search_ops/n8n as JSON files.

End of N8N_WORKFLOWS.md
