# Supabase RLS Policy Guidance
Version 1.0

## Purpose

This document defines recommended Row Level Security (RLS) patterns for multi client data isolation.

## Model

- Clients, sites, and all related artifacts must be isolated by client.
- Access should be granted by role and by client, not by broad table access.

## Recommended Approach

1. Enable RLS on all tables.
2. Create a mapping table that ties authenticated users to client slugs.
3. Use policies that enforce site.client_id membership via the mapping table.
4. Maintain a separate service role key for n8n automations that must write logs.

## Guidance Notes

- Humans should use least privilege and access only their assigned clients.
- n8n should write through a service role only where required.
- Avoid storing secrets in the database. Store references only.

## Validation

- Attempt cross client reads as a test user, expect denial.
- Attempt writes without membership, expect denial.

End of SUPABASE_RLS_POLICY.md
