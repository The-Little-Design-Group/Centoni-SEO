# Supabase Data Dictionary
Version 1.0

## clients
- name: client legal name
- slug: unique identifier used across repos and automations

## sites
- client_id: owning client
- canonical_domain: canonical domain for reporting and validation

## properties
- gsc_property_identifier: domain or URL prefix property
- ga4_property_id: GA4 property id
- gtm_container_id: GTM container id
- gbp_profile_id: GBP profile id

## baselines
- window_start, window_end: baseline measurement window
- gsc and ga4 fields: captured metrics used as observed facts
- notes: factual notes and known limitations

## inspections
- environment: baseline, sandbox, production_readonly, production_write
- findings: JSON payload storing structured inspection outcomes

## backlog_items
- signal_category: SEO, AEO, GEO, performance, compliance
- evidence_refs: JSON array referencing evidence entry ids or repo paths
- status: open, in_progress, blocked, done

## validations
- outcome: successful, partial, failed
- tooling: JSON payload listing tools used and outputs

## evidence_entries
- claim: the statement being supported
- claim_classification: observed fact, verified external fact, derived conclusion, inference, assumption
- verification_status: verified, single_source, pending, rejected

End of SUPABASE_DATA_DICTIONARY.md
