# MCP Inventory
Version 1.0

## Purpose

Single source of truth for MCPs approved for Search Ops.

## Inventory Template

- MCP name:
- Category:
- Owner:
- Read operations:
- Write operations:
- Logging location:
- Failure modes:
- Rollback plan:
- Status: (candidate, piloting, approved, deprecated)
- Notes:

End of MCP_INVENTORY.md
