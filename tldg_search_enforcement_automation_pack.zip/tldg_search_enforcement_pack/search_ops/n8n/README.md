# n8n Exports
Version 1.0

Place exported n8n workflow JSON files in this folder.

Naming standard:
- 01_repo_bootstrap.json
- 02_access_reminders.json
- 03_weekly_gsc_pull.json
- 04_weekly_ga4_pull.json
- 05_playwright_validation.json
- 06_jira_ticket_creator.json
- 07_failure_notifications.json

End of search_ops/n8n/README.md
