-- TLDG Search Ops, Supabase Schema
-- Version 1.0
-- Notes: Enable pgcrypto extension for gen_random_uuid if needed.

create table if not exists clients (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists sites (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references clients(id) on delete cascade,
  name text not null,
  slug text not null,
  canonical_domain text not null,
  created_at timestamptz not null default now(),
  unique (client_id, slug)
);

create table if not exists properties (
  id uuid primary key default gen_random_uuid(),
  site_id uuid not null references sites(id) on delete cascade,
  gsc_property_type text,
  gsc_property_identifier text,
  ga4_property_id text,
  gtm_container_id text,
  gbp_profile_id text,
  created_at timestamptz not null default now()
);

create table if not exists baselines (
  id uuid primary key default gen_random_uuid(),
  site_id uuid not null references sites(id) on delete cascade,
  window_start date not null,
  window_end date not null,
  gsc_clicks bigint,
  gsc_impressions bigint,
  gsc_ctr numeric,
  gsc_position numeric,
  ga4_organic_sessions bigint,
  ga4_organic_users bigint,
  ga4_engagement_rate numeric,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists inspections (
  id uuid primary key default gen_random_uuid(),
  site_id uuid not null references sites(id) on delete cascade,
  environment text not null,
  findings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists backlog_items (
  id uuid primary key default gen_random_uuid(),
  site_id uuid not null references sites(id) on delete cascade,
  external_ticket_key text,
  title text not null,
  signal_category text not null,
  risk_level text not null,
  scope text,
  evidence_refs jsonb not null default '[]'::jsonb,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table if not exists validations (
  id uuid primary key default gen_random_uuid(),
  site_id uuid not null references sites(id) on delete cascade,
  backlog_item_id uuid references backlog_items(id) on delete set null,
  environment text not null,
  outcome text not null,
  tooling jsonb not null default '{}'::jsonb,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists evidence_entries (
  id uuid primary key default gen_random_uuid(),
  site_id uuid not null references sites(id) on delete cascade,
  claim text not null,
  claim_classification text not null,
  source_type text,
  source_reference text,
  vetting_notes text,
  verification_status text,
  created_at timestamptz not null default now()
);

create index if not exists idx_sites_client_id on sites(client_id);
create index if not exists idx_baselines_site_id on baselines(site_id);
create index if not exists idx_backlog_site_id on backlog_items(site_id);
create index if not exists idx_validations_site_id on validations(site_id);
create index if not exists idx_evidence_site_id on evidence_entries(site_id);
