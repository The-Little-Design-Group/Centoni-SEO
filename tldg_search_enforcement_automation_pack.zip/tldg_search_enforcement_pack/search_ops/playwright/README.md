# Playwright Search Checks
Version 1.0

## Purpose

This test suite provides regression checks for SEO and schema signals.

## Setup

- Node 20
- Install dependencies: npm ci
- Set BASE_URL, example:
  BASE_URL="https://example.com" npm test

## Notes

These tests validate observable signals only. They do not claim ranking outcomes.
