// TLDG Search Playwright Config
// BASE_URL must be provided via environment variable.
const { defineConfig } = require('@playwright/test');

module.exports = defineConfig({
  testDir: './tests',
  timeout: 60_000,
  retries: 0,
  use: {
    baseURL: process.env.BASE_URL,
    headless: true
  },
  reporter: [['list']]
});
