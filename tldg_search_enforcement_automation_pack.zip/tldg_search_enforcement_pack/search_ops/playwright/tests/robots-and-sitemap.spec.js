const { test, expect } = require('@playwright/test');

test('robots.txt is reachable and returns 200', async ({ request, baseURL }) => {
  const res = await request.get(new URL('/robots.txt', baseURL).toString());
  expect(res.status()).toBe(200);
  const body = await res.text();
  expect(body.length).toBeGreaterThan(0);
});

test('sitemap is discoverable from robots.txt when present', async ({ request, baseURL }) => {
  const robots = await request.get(new URL('/robots.txt', baseURL).toString());
  expect(robots.status()).toBe(200);
  const body = await robots.text();
  const sitemapLine = body.split('\n').find(l => /^sitemap\s*:/i.test(l.trim()));
  if (!sitemapLine) {
    test.skip(true, 'No sitemap directive found in robots.txt');
  }
  const sitemapUrl = sitemapLine.split(':').slice(1).join(':').trim();
  const res = await request.get(sitemapUrl);
  expect([200, 301, 302].includes(res.status())).toBeTruthy();
});
