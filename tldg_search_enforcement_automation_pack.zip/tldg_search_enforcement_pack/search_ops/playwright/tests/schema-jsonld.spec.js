const { test, expect } = require('@playwright/test');

function tryParseJson(text) {
  try { return JSON.parse(text); } catch { return null; }
}

test('JSON-LD blocks parse as valid JSON', async ({ page }) => {
  await page.goto('/');
  const blocks = page.locator('script[type="application/ld+json"]');
  const count = await blocks.count();
  if (!count) test.skip(true, 'No JSON-LD blocks found');
  for (let i = 0; i < count; i++) {
    const text = (await blocks.nth(i).textContent()) || '';
    const parsed = tryParseJson(text.trim());
    expect(parsed).not.toBeNull();
  }
});
