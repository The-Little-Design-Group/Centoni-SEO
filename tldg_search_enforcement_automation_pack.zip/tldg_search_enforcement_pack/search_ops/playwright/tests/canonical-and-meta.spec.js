const { test, expect } = require('@playwright/test');

test('page has a canonical link tag', async ({ page }) => {
  await page.goto('/');
  const canonical = page.locator('link[rel="canonical"]');
  await expect(canonical).toHaveCount(1);
  const href = await canonical.first().getAttribute('href');
  expect(href).toBeTruthy();
});

test('page is not accidentally noindex', async ({ page }) => {
  await page.goto('/');
  const robotsMeta = page.locator('meta[name="robots"]');
  if (await robotsMeta.count()) {
    const content = (await robotsMeta.first().getAttribute('content')) || '';
    expect(content.toLowerCase()).not.toContain('noindex');
  }
});
