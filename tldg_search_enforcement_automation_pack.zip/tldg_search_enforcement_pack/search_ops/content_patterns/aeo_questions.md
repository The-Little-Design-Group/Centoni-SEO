# AEO Question Pattern
Version 1.0

## Purpose

Standard format for question driven content designed for answer extraction and clarity.

## Structure

1. One question per heading
2. Answer immediately in 40 to 90 words
3. Expand with supporting detail
4. Add internal links to deeper pages
5. Where appropriate, add FAQPage schema for the exact questions

## Example Template

## What is <topic>?

<Direct answer paragraph. Keep it plain, specific, and factual.>

<Supporting paragraphs that add depth, examples, constraints, and next steps.>

End of aeo_questions.md
