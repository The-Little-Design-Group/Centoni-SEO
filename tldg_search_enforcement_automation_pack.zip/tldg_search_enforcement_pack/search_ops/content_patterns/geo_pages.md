# GEO Page Pattern
Version 1.0

## Purpose

Standard format for location and market pages that preserve entity clarity and avoid thin content.

## Structure

- H1: Service or topic plus location
- Intro: local context and direct value proposition
- Primary sections: services, process, coverage area, FAQs
- Entity references: consistent NAP where applicable
- Internal links: nearby locations, relevant resources
- Avoid duplicated paragraphs across locations, write unique local context

End of geo_pages.md
